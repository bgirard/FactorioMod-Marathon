require("prototypes.recipe")

data.raw["item"]["pipe"].stack_size = 100
